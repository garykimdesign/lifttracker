// LiftTracker service worker: offline app shell + runtime caching.
// Bump CACHE on every deploy so clients pick up the new shell.
const CACHE = 'lt-v2.2.0';
const SHELL = [
  './', './index.html', './manifest.webmanifest', './css/app.css', './data/exercises.json',
  './js/main.js', './js/store.js', './js/ui.js', './js/utils.js', './js/icons.js', './js/cloud.js', './js/firebase-config.js', './js/install.js', './js/importers.js',
  './js/data/templates.js',
  './js/components/charts.js', './js/components/picker.js', './js/components/plates.js', './js/components/summary.js', './js/components/exercise-detail.js', './js/components/routine-editor.js', './js/components/session-detail.js', './js/components/import.js',
  './js/views/home.js', './js/views/train.js', './js/views/library.js', './js/views/progress.js', './js/views/settings.js', './js/views/workout.js',
  './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png', './icons/apple-touch-icon.png',
];
const IMMUTABLE_HOSTS = ['fonts.gstatic.com', 'www.gstatic.com'];
const NEVER_CACHE = ['firestore.googleapis.com', 'identitytoolkit.googleapis.com', 'securetoken.googleapis.com', 'www.googleapis.com', 'accounts.google.com', 'apis.google.com'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (NEVER_CACHE.some((h) => url.hostname.endsWith(h))) return;
  if (url.hostname === 'fonts.googleapis.com' || IMMUTABLE_HOSTS.includes(url.hostname)) { e.respondWith(cacheFirst(req)); return; }
  if (url.origin === location.origin) {
    e.respondWith(req.mode === 'navigate' ? networkFirst(req, './index.html') : networkFirst(req));
  }
});

async function cacheFirst(req) {
  const cached = await caches.match(req);
  if (cached) return cached;
  try { const res = await fetch(req); if (res.ok || res.type === 'opaque') (await caches.open(CACHE)).put(req, res.clone()); return res; }
  catch { return cached || Response.error(); }
}
async function networkFirst(req, fallback) {
  try {
    const res = await fetch(req);
    if (res.ok) (await caches.open(CACHE)).put(req, res.clone());
    return res;
  } catch {
    return (await caches.match(req)) || (fallback && (await caches.match(fallback))) || Response.error();
  }
}

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => { const c = list[0]; if (c) return c.focus(); return self.clients.openWindow('./'); }));
});
