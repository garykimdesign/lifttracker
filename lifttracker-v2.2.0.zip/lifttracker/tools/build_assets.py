#!/usr/bin/env python3
"""Generates the compact exercise library and PWA icons.

Usage:  python3 tools/build_assets.py [path/to/exercisesData.json]

- data/exercises.json : [[id, name, muscleGroup], ...]  (compact tuple form)
- icons/icon-{192,512}.png, icons/maskable-512.png, icons/apple-touch-icon.png
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = sys.argv[1] if len(sys.argv) > 1 else '/tmp/lt/src/src/data/exercisesData.json'

# Short, classic names that the big library lacks. They make the picker friendlier
# and give the default routines sensible entries.
CLASSICS = [
    ('Bench Press (Barbell)', 'Chest'),
    ('Incline Bench Press (Dumbbell)', 'Chest'),
    ('Squat (Barbell)', 'Quadriceps'),
    ('Deadlift (Barbell)', 'Back'),
    ('Romanian Deadlift (Barbell)', 'Hamstrings'),
    ('Overhead Press (Barbell)', 'Shoulders'),
    ('Overhead Press (Dumbbell)', 'Shoulders'),
    ('Lateral Raise (Dumbbell)', 'Shoulders'),
    ('Pull Up', 'Back'),
    ('Chin Up', 'Back'),
    ('Lat Pulldown (Cable)', 'Back'),
    ('Seated Row (Cable)', 'Back'),
    ('Bent Over Row (Barbell)', 'Back'),
    ('Bicep Curl (Dumbbell)', 'Biceps'),
    ('Hammer Curl (Dumbbell)', 'Biceps'),
    ('Tricep Extension (Cable)', 'Triceps'),
    ('Tricep Pushdown (Cable)', 'Triceps'),
    ('Skull Crusher (Barbell)', 'Triceps'),
    ('Dip', 'Triceps'),
    ('Leg Press', 'Quadriceps'),
    ('Leg Extension', 'Quadriceps'),
    ('Leg Curl', 'Hamstrings'),
    ('Hip Thrust (Barbell)', 'Glutes'),
    ('Calf Raise', 'Calves'),
    ('Crunch', 'Abdominals'),
    ('Plank', 'Abdominals'),
    ('Face Pull (Cable)', 'Shoulders'),
    ('Shrug (Dumbbell)', 'Trapezius'),
]


def slug(name):
    return 'ex-' + re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')


def build_exercises():
    with open(SRC) as f:
        raw = json.load(f)
    seen = set()
    out = []
    for name, muscle in CLASSICS:
        sid = slug(name)
        seen.add(sid)
        out.append([sid, name, muscle])
    for e in raw:
        sid = str(e['id']).strip()
        if sid in seen or not e.get('name'):
            continue
        seen.add(sid)
        out.append([sid, e['name'].strip(), (e.get('muscleGroup') or 'Other').strip()])
    os.makedirs(os.path.join(ROOT, 'data'), exist_ok=True)
    with open(os.path.join(ROOT, 'data', 'exercises.json'), 'w') as f:
        json.dump(out, f, separators=(',', ':'), ensure_ascii=False)
    print(f'exercises: {len(out)} -> data/exercises.json')


def build_icons():
    from PIL import Image, ImageDraw

    def draw(size, padding_ratio, bg=(13, 16, 15), accent=(74, 222, 128)):
        img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        r = int(size * 0.22)
        d.rounded_rectangle([0, 0, size - 1, size - 1], radius=r, fill=bg)
        # dumbbell: bar + two plates per side, rotated 45deg feel via straight bar for crispness
        pad = int(size * padding_ratio)
        cy = size // 2
        bar_h = max(2, int(size * 0.07))
        d.rounded_rectangle([pad, cy - bar_h // 2, size - pad, cy + bar_h // 2], radius=bar_h // 2, fill=(230, 236, 232))
        plate_w = int(size * 0.075)
        plate_h_big = int(size * 0.40)
        plate_h_small = int(size * 0.28)
        gap = int(size * 0.02)
        for sign in (-1, 1):
            # inner (big) plate
            x0 = pad + int(size * 0.14) if sign == -1 else size - pad - int(size * 0.14) - plate_w
            d.rounded_rectangle([x0, cy - plate_h_big // 2, x0 + plate_w, cy + plate_h_big // 2], radius=plate_w // 2, fill=accent)
            # outer (small) plate
            x1 = x0 - gap - plate_w if sign == -1 else x0 + plate_w + gap
            d.rounded_rectangle([x1, cy - plate_h_small // 2, x1 + plate_w, cy + plate_h_small // 2], radius=plate_w // 2, fill=accent)
        return img

    icons = os.path.join(ROOT, 'icons')
    os.makedirs(icons, exist_ok=True)
    draw(512, 0.14).save(os.path.join(icons, 'icon-512.png'))
    draw(192, 0.14).save(os.path.join(icons, 'icon-192.png'))
    draw(180, 0.14).save(os.path.join(icons, 'apple-touch-icon.png'))
    # Maskable: content inside the safe zone (center 80%), opaque background all over
    m = Image.new('RGBA', (512, 512), (13, 16, 15, 255))
    inner = draw(512, 0.24)
    m.alpha_composite(inner)
    m.save(os.path.join(icons, 'maskable-512.png'))
    print('icons -> icons/')


if __name__ == '__main__':
    build_exercises()
    build_icons()
