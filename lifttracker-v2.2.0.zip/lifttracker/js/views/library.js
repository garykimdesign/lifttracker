// Library: searchable exercise catalogue (3k+), muscle filters, favorites, custom exercises.
import { I } from '../icons.js';
import { esc } from '../utils.js';
import { state, allExercises, toggleFavorite } from '../store.js';
import { filterExercises, exerciseRow, filterBarHtml, openCreateExercise } from '../components/picker.js';
import { openExerciseDetail } from '../components/exercise-detail.js';

const LIMIT = 150;
const f = { q: '', muscle: null, favorites: false }; // persists across re-renders

export function render(root) {
  root.innerHTML = `
    <div class="view-head"><h1>Library</h1></div>
    <div data-bar>${filterBarHtml(f)}</div>
    <div class="picker-list" data-list role="list"></div>`;
  const bar = root.querySelector('[data-bar]'), list = root.querySelector('[data-list]');
  const renderList = () => {
    const all = filterExercises(f);
    const shown = all.slice(0, LIMIT);
    const groups = new Map();
    const grouped = !f.q && !f.favorites;
    for (const e of shown) { const g = grouped ? e.muscleGroup : ''; if (!groups.has(g)) groups.set(g, []); groups.get(g).push(e); }
    list.innerHTML = shown.length
      ? [...groups.entries()].map(([g, items]) => `${g ? `<div class="picker-group eyebrow">${esc(g)}</div>` : ''}${items.map((e) => exerciseRow(e, { showTile: false })).join('')}`).join('') + (all.length > LIMIT ? `<p class="muted" style="text-align:center;padding:14px;font-size:13px">Showing ${LIMIT} of ${all.length.toLocaleString()} — refine your search</p>` : '')
      : `<div class="empty"><div class="ico">${f.favorites ? I.star : I.search}</div><h3>${f.favorites && !f.q ? 'No favorites yet' : 'No matches'}</h3><p>${f.favorites && !f.q ? 'Tap the star on any exercise to pin it here.' : `Create “${esc(f.q)}” as a custom exercise.`}</p>${f.q ? `<button class="btn btn-primary" data-create-q>${I.plus} Create “${esc(f.q.slice(0, 30))}”</button>` : ''}</div>`;
  };
  renderList();
  const rebar = () => { bar.innerHTML = filterBarHtml(f); };
  bar.addEventListener('input', (e) => { if (e.target.matches('[data-q]')) { f.q = e.target.value; bar.querySelector('[data-clear]').classList.toggle('hidden', !f.q); renderList(); } });
  bar.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.matches('[data-clear]')) { f.q = ''; rebar(); renderList(); bar.querySelector('[data-q]').focus(); }
    else if (b.matches('[data-fav]')) { f.favorites = !f.favorites; rebar(); renderList(); }
    else if (b.matches('[data-muscle]')) { f.muscle = b.dataset.muscle || null; rebar(); renderList(); }
    else if (b.matches('[data-new]')) openCreateExercise({ muscle: f.muscle, name: f.q }).then((ex) => { if (ex) { f.q = ''; rebar(); renderList(); openExerciseDetail(ex); } });
  });
  list.addEventListener('click', (e) => {
    const star = e.target.closest('[data-star]');
    if (star) { const on = toggleFavorite(star.dataset.star); star.classList.toggle('on', on); star.innerHTML = on ? I.starFill : I.star; if (f.favorites && !on) renderList(); return; }
    if (e.target.closest('[data-create-q]')) { openCreateExercise({ muscle: f.muscle, name: f.q }).then((ex) => { if (ex) { f.q = ''; rebar(); renderList(); openExerciseDetail(ex); } }); return; }
    const row = e.target.closest('[data-ex]'); if (!row) return;
    const ex = allExercises().find((x) => x.id === row.dataset.ex); if (ex) openExerciseDetail(ex);
  });
}
