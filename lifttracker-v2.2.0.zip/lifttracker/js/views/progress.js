// Progress: weekly volume, calendar, body weight, full history and the PR leaderboard.
import { I } from '../icons.js';
import { esc, fmtW, fmtVol, fmtDate, fmtDuration, timeAgo, convert, isNum, download, csvRow } from '../utils.js';
import { toast, menu, numField, parseNum } from '../ui.js';
import { state, weeklySeries, prBoard, addBodyweight, deleteBodyweight, sessionSets, sessionVolume, findExerciseByName, exportAll } from '../store.js';
import { barChart, heatmap, sparkline, lineChart } from '../components/charts.js';
import { openSessionDetail } from '../components/session-detail.js';
import { openExerciseDetail } from '../components/exercise-detail.js';
import { openImportSheet } from '../components/import.js';

let tab = 'overview';
const bw = () => state.bodyweight;

export function render(root) {
  const unit = state.settings.unit;
  root.innerHTML = `
    <div class="view-head">
      <h1>Progress</h1>
      <button class="btn btn-icon" data-export aria-label="Export">${I.download}</button>
    </div>
    <div class="seg block" style="margin-bottom:18px">${['overview', 'history', 'records'].map((t) => `<button class="${tab === t ? 'on' : ''}" data-tab="${t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div>
    <div data-pane>${tab === 'overview' ? overview(unit) : tab === 'history' ? history(unit) : records(unit)}</div>`;

  root.onclick = (e) => {
    const b = e.target.closest('button,[data-session],[data-ex]'); if (!b) return;
    if (b.dataset.tab) { tab = b.dataset.tab; render(root); return; }
    if (b.matches('[data-import]')) return openImportSheet();
    if (b.matches('[data-export]')) return menu(b, [
      { label: 'Export history (CSV)', icon: I.download, onClick: exportCsv },
      { label: 'Export everything (JSON)', icon: I.download, onClick: () => { download(`lifttracker-backup-${new Date().toISOString().slice(0, 10)}.json`, exportAll()); } },
      '-',
      { label: 'Import history / backup…', icon: I.upload, onClick: openImportSheet },
    ]);
    if (b.dataset.session) return openSessionDetail(b.dataset.session);
    if (b.dataset.ex) { const ex = findExerciseByName(b.dataset.ex) || { id: `name:${b.dataset.ex}`, name: b.dataset.ex, muscleGroup: 'Other' }; return openExerciseDetail(ex); }
    if (b.matches('[data-bw-add]')) { const inp = root.querySelector('[data-bw-in]'); const v = parseNum(inp.value); if (!isNum(v) || v <= 0) { inp.focus(); return; } addBodyweight(v); toast('Body weight logged'); return; }
    if (b.matches('[data-bw-del]')) { deleteBodyweight(+b.dataset.bwDel); return; }
  };
  root.querySelector('[data-bw-in]')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') root.querySelector('[data-bw-add]').click(); });
}

function overview(unit) {
  const series = weeklySeries(12);
  const volNow = series[series.length - 1].volume, volAvg = series.slice(0, -1).reduce((a, w) => a + w.volume, 0) / Math.max(1, series.slice(0, -1).filter((w) => w.count).length || 1);
  const list = bw();
  const last = list[list.length - 1];
  const toU = (kg) => (unit === 'kg' ? kg : convert(kg, 'kg', 'lbs'));
  const pts = list.slice(-20).map((b) => ({ t: b.t, v: toU(b.kg) }));
  const first30 = list.find((b) => b.t >= Date.now() - 30 * 86400000);
  return `
    <div class="card card-pad">
      <div class="section-head" style="margin-bottom:6px"><h2>Weekly volume</h2><span class="muted" style="font-size:12px;font-weight:700">12 weeks · ${unit}</span></div>
      ${state.history.length ? `<div class="row" style="gap:16px;margin-bottom:8px"><div><div class="val num" style="font-size:24px;font-weight:800">${fmtVol(volNow)}</div><div class="muted" style="font-size:12px;font-weight:700">this week</div></div><div><div class="num" style="font-size:16px;font-weight:700;color:var(--text-2)">${fmtVol(volAvg)}</div><div class="muted" style="font-size:12px;font-weight:700">avg active week</div></div></div>${barChart(series, { h: 150 })}` : `<p class="muted" style="font-size:14px">Your training volume per week will chart here.</p>`}
    </div>
    <div class="card card-pad" style="margin-top:12px">
      <div class="section-head" style="margin-bottom:10px"><h2>Consistency</h2><span class="muted" style="font-size:12px;font-weight:700">last 16 weeks</span></div>
      ${heatmap(state.history, { weeks: 16, weekStartsMonday: state.settings.weekStartsMonday })}
    </div>
    <div class="card card-pad" style="margin-top:12px">
      <div class="section-head" style="margin-bottom:10px"><h2>Body weight</h2>${last ? `<span class="muted" style="font-size:12px;font-weight:700">${timeAgo(last.t)}</span>` : ''}</div>
      <div class="row" style="gap:14px;align-items:flex-end">
        <div style="flex:1">${last ? `<div class="val num" style="font-size:28px;font-weight:800;letter-spacing:-.03em">${fmtW(toU(last.kg), unit)}<small class="muted" style="font-size:13px;margin-left:4px">${unit}</small></div>${first30 && first30 !== last ? `<div class="muted" style="font-size:12px;font-weight:700">${(toU(last.kg) - toU(first30.kg)) >= 0 ? '+' : ''}${fmtW(toU(last.kg) - toU(first30.kg), unit)} ${unit} in 30 days</div>` : ''}` : `<p class="muted" style="font-size:13.5px">Log your weight to see it alongside your lifts.</p>`}</div>
        <div style="width:150px">${sparkline(pts.map((p) => p.v))}</div>
      </div>
      <div class="row" style="margin-top:14px;gap:8px"><div style="flex:1">${numField({ value: last ? fmtW(toU(last.kg), unit) : '', step: unit === 'kg' ? 0.1 : 0.2, placeholder: `Today’s weight (${unit})`, attrs: 'data-bw-in' })}</div><button class="btn btn-primary" data-bw-add>Log</button></div>
      ${pts.length >= 2 ? `<div style="margin-top:14px">${lineChart(pts, { h: 160, fmt: (v) => fmtW(v, unit), label: 'Body weight trend' })}</div>` : ''}
      ${list.length ? `<details style="margin-top:10px"><summary class="muted" style="font-size:12.5px;font-weight:700;cursor:pointer">All entries (${list.length})</summary><div class="list" style="margin-top:6px">${[...list].reverse().slice(0, 30).map((b) => `<div class="list-item" style="padding:8px 4px"><span style="flex:1;font-size:13.5px">${fmtDate(b.t)}</span><b class="num">${fmtW(toU(b.kg), unit)}</b><button class="btn btn-icon btn-ghost btn-sm" data-bw-del="${b.t}" aria-label="Delete">${I.x}</button></div>`).join('')}</div></details>` : ''}
    </div>`;
}

function history(unit) {
  if (!state.history.length) return `<div class="empty"><div class="ico">${I.history}</div><h3>Nothing logged yet</h3><p>Finished workouts appear here, grouped by month. Coming from another app? Bring your history with you.</p><button class="btn" data-import>${I.upload} Import from Strong / Hevy / CSV</button></div>`;
  const groups = new Map();
  for (const s of state.history) { const k = new Date(s.startTime).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(s); }
  return [...groups.entries()].map(([k, list]) => `
    <div class="section" style="margin-top:6px"><div class="section-head"><h2>${esc(k)}</h2><span class="muted" style="font-size:12px;font-weight:700">${list.length} workout${list.length === 1 ? '' : 's'} · ${fmtVol(list.reduce((a, s) => a + sessionVolume(s), 0))} ${unit}</span></div>
    <div class="card" style="padding:4px 14px">${list.map((s) => `<div class="list-item click" data-session="${s.id}">
      <div class="date-tile"><span class="m">${new Date(s.startTime).toLocaleDateString(undefined, { weekday: 'short' })}</span><span class="d">${new Date(s.startTime).getDate()}</span></div>
      <div style="flex:1;min-width:0"><b style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(s.name)}</b><div class="meta" style="margin-top:3px"><span>${fmtDuration((s.endTime || s.startTime) - s.startTime, { long: true })}</span><span>${fmtVol(sessionVolume(s))} ${unit}</span><span>${sessionSets(s)} sets</span>${s.records ? `<span class="pr">${I.trophy}${s.records}</span>` : ''}</div><div class="muted" style="font-size:12px;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${(s.exercises || []).map((we) => we.exercise?.name).filter(Boolean).join(' · ')}</div></div>
      ${I.chevronRight}</div>`).join('')}</div></div>`).join('');
}

function records(unit) {
  const board = prBoard(30);
  if (!board.length) return `<div class="empty"><div class="ico">${I.trophy}</div><h3>No records yet</h3><p>Complete sets with weight and reps and your bests will rank here by estimated 1RM.</p></div>`;
  const recentPrs = state.history.flatMap((s) => (s.prs || []).map((p) => ({ ...p, t: s.startTime, unit: s.unit || 'lbs' }))).slice(0, 8);
  return `
    ${recentPrs.length ? `<div class="card card-pad" style="margin-bottom:12px;background:var(--warn-soft);border-color:color-mix(in srgb,var(--warn) 35%,transparent)"><div class="eyebrow" style="color:var(--warn)">Latest PRs</div><div class="stack" style="gap:6px;margin-top:8px">${recentPrs.map((p) => `<div class="row between" style="font-size:14px"><span><b>${esc(p.exercise)}</b> <span class="muted">· ${fmtDate(p.t)}</span></span><span class="num" style="font-weight:700">${fmtW(convert(p.weight, p.unit, unit), unit)}×${p.reps}</span></div>`).join('')}</div></div>` : ''}
    <div class="card" style="padding:4px 14px">
      <div class="list-item" style="padding:10px 6px 6px"><span class="eyebrow" style="flex:1">Exercise</span><span class="eyebrow" style="width:64px;text-align:right">Best</span><span class="eyebrow" style="width:64px;text-align:right">E1RM</span></div>
      ${board.map((b, i) => `<div class="list-item click" data-ex="${esc(b.name)}"><div class="avatar-letter" style="width:34px;height:34px;border-radius:10px;font-size:13px;${i < 3 ? 'background:var(--warn-soft);color:var(--warn)' : ''}">${i + 1}</div><div style="flex:1;min-width:0"><b style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(b.name)}</b><div class="muted" style="font-size:12px">${b.sessions} session${b.sessions === 1 ? '' : 's'} · ${b.count} sets</div></div><span class="num" style="width:64px;text-align:right;font-weight:700">${fmtW(b.weight, unit)}</span><span class="num" style="width:64px;text-align:right;font-weight:800;color:var(--accent-strong)">${fmtW(b.e1rm, unit)}</span></div>`).join('')}
    </div>`;
}

function exportCsv() {
  const rows = [csvRow(['date', 'time', 'workout', 'exercise', 'muscle', 'set', 'type', 'weight', 'unit', 'reps', 'pr'])];
  for (const s of [...state.history].reverse()) for (const we of s.exercises || []) (we.sets || []).forEach((st, i) => rows.push(csvRow([new Date(s.startTime).toISOString().slice(0, 10), new Date(s.startTime).toTimeString().slice(0, 5), s.name, we.exercise?.name, we.exercise?.muscleGroup, i + 1, st.type || '', st.weight, s.unit || 'lbs', st.reps, (st.pr || []).join('|')])));
  download(`lifttracker-history-${new Date().toISOString().slice(0, 10)}.csv`, rows.join('\n'), 'text/csv');
  toast('CSV exported');
}
