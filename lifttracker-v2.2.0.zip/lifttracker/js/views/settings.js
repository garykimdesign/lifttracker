// Settings sheet: account & sync, preferences, data management, about.
import { I } from '../icons.js';
import { esc, download } from '../utils.js';
import { openModal, confirm, prompt, toast, numField, parseNum } from '../ui.js';
import { state, subscribe, setSetting, updateProfile, displayName, photoUrl, signIn, signOut, resync, exportAll, clearLocalData } from '../store.js';
import { cloud } from '../cloud.js';
import { installState, promptInstall } from '../install.js';
import { openImportSheet } from '../components/import.js';

export const APP_VERSION = '2.2.0';
const REST = [[30, '30s'], [45, '45s'], [60, '1:00'], [90, '1:30'], [120, '2:00'], [150, '2:30'], [180, '3:00'], [240, '4:00'], [300, '5:00']];

export function openSettings() {
  let unsub = null;
  const h = openModal({
    title: 'Settings', full: true,
    html: `<div data-body></div>`,
    onMount(h) {
      const body = h.body.querySelector('[data-body]');
      const render = () => { const y = body.parentElement.scrollTop; body.innerHTML = html(); body.parentElement.scrollTop = y; };
      render();
      unsub = subscribe((r) => { if (['settings', 'auth', 'cloud', 'profile', 'bodyweight'].includes(r)) render(); });
      body.addEventListener('click', async (e) => {
        const b = e.target.closest('button'); if (!b) return;
        const s = state.settings;
        if (b.dataset.set) { const [k, v] = b.dataset.set.split(':'); setSetting(k, v === 'true' ? true : v === 'false' ? false : v); return; }
        if (b.dataset.toggle) { setSetting(b.dataset.toggle, !s[b.dataset.toggle]); return; }
        if (b.matches('[data-signin]')) {
          b.disabled = true; b.innerHTML = `<span class="spinner"></span> Connecting…`;
          try { await signIn(); toast('Signed in — syncing your data'); }
          catch (err) {
            const code = err?.code || '';
            toast(code === 'auth/unauthorized-domain' ? 'This domain isn’t authorized in Firebase yet (see README)' : code === 'auth/popup-closed-by-user' ? 'Sign-in cancelled' : `Sign-in failed: ${esc(err?.message || code || 'unknown error')}`, { duration: 6000 });
            render();
          }
          return;
        }
        if (b.matches('[data-signout]')) { if (await confirm({ title: 'Sign out?', text: 'Your data stays in the cloud. This device starts fresh with the starter routines.', confirmText: 'Sign out' })) { await signOut(); toast('Signed out'); } return; }
        if (b.matches('[data-resync]')) { await resync(); toast(state.cloud === 'ok' ? 'Everything is in sync' : `Sync problem: ${esc(state.lastError || '')}`); return; }
        if (b.matches('[data-name]')) { const n = await prompt({ title: 'Your name', value: displayName() === 'Lifter' ? '' : displayName(), placeholder: 'Name' }); if (n !== null) updateProfile({ name: n.trim() }); return; }
        if (b.matches('[data-export-all]')) { download(`lifttracker-backup-${new Date().toISOString().slice(0, 10)}.json`, exportAll()); toast('Backup downloaded'); return; }
        if (b.matches('[data-export-routines]')) { download(`lifttracker-routines-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify({ app: 'LiftTracker', unit: s.unit, templates: state.templates }, null, 2)); return; }
        if (b.matches('[data-import]')) { openImportSheet(); return; }
        if (b.matches('[data-clear]')) { if (await confirm({ title: 'Clear data on this device?', text: state.user ? 'Cloud data is kept; you’ll be signed out here.' : 'This deletes all routines and history stored on this device. Export a backup first.', confirmText: 'Clear' })) { if (state.user) await signOut().catch(() => {}); clearLocalData(); location.reload(); } return; }
        if (b.matches('[data-install]')) { promptInstall(); return; }
      });
      body.addEventListener('change', (e) => {
        const t = e.target;
        if (t.dataset.num) { const v = parseNum(t.value); if (v !== '' && v >= 0) setSetting(t.dataset.num, v); }
      });
    },
    onClose() { unsub?.(); },
  });
  return h;
}

function html() {
  const s = state.settings, u = state.user;
  const name = displayName(), photo = photoUrl();
  const seg = (key, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${String(s[key]) === String(v) ? 'on' : ''}" data-set="${key}:${v}">${l}</button>`).join('')}</div>`;
  const sw = (key) => `<button class="switch" role="switch" aria-checked="${!!s[key]}" data-toggle="${key}"></button>`;
  const row = (t, d, ctl) => `<div class="setting-row"><div style="min-width:0"><div class="t">${t}</div>${d ? `<div class="d">${d}</div>` : ''}</div>${ctl}</div>`;
  const syncLabel = { ok: 'Synced', syncing: 'Syncing…', connecting: 'Connecting…', error: 'Sync error', off: 'Offline only', disabled: 'Cloud disabled' }[state.cloud] || state.cloud;
  return `
    <div class="card card-pad" style="display:flex;align-items:center;gap:14px">
      <div class="avatar lg">${photo ? `<img src="${esc(photo)}" alt="" referrerpolicy="no-referrer">` : esc(name.charAt(0).toUpperCase())}</div>
      <div style="flex:1;min-width:0">
        <div class="row" style="gap:6px"><h3 style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(name)}</h3><button class="btn btn-icon btn-ghost btn-sm" data-name aria-label="Edit name">${I.edit}</button></div>
        <div class="muted" style="font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${u ? esc(u.email) : 'Data is stored on this device'}</div>
        <div class="row" style="gap:6px;margin-top:6px;font-size:12px;font-weight:700;color:var(--text-2)"><span class="sync-dot ${state.cloud}"></span>${syncLabel}${state.cloud === 'error' && state.lastError ? `<span class="muted" title="${esc(state.lastError)}">· ${esc(state.lastError.slice(0, 48))}</span>` : ''}</div>
      </div>
    </div>
    ${cloud.enabled ? (u
      ? `<div class="row" style="margin-top:10px;gap:8px"><button class="btn" style="flex:1" data-resync>${I.refresh} Re-sync</button><button class="btn" style="flex:1" data-signout>${I.logout} Sign out</button></div>`
      : `<button class="btn btn-lg btn-block google-btn" style="margin-top:10px" data-signin>${I.google} Continue with Google</button><p class="muted" style="font-size:12.5px;text-align:center;margin-top:8px">Back up and sync routines, history and settings across devices. Your local data moves to your account on first sign-in.</p>`)
    : ''}

    <div class="section"><div class="section-head"><h2>Workout</h2></div><div class="card" style="padding:4px 18px">
      ${row('Units', 'Switching converts your routines', seg('unit', [['lbs', 'lbs'], ['kg', 'kg']]))}
      ${row('Default rest', 'Used unless an exercise sets its own', `<select class="select" style="width:auto" data-rest-sel>${REST.map(([v, l]) => `<option value="${v}" ${s.restDefault === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`)}
      ${row('Auto-start rest timer', 'After each completed set', sw('autoRest'))}
      ${row('Timer sound', '', sw('restSound'))}
      ${row('Timer vibration', 'On supported phones', sw('restVibrate'))}
      ${row('Weekly goal', 'Workouts per week', `<div style="width:130px">${numField({ value: s.weeklyGoal, step: 1, min: 1, inputmode: 'numeric', attrs: 'data-num="weeklyGoal"' })}</div>`)}
      ${row('Week starts on', '', seg('weekStartsMonday', [['true', 'Mon'], ['false', 'Sun']]))}
      ${row('Bar weight', `For the plate calculator (${s.unit})`, `<div style="width:130px">${numField({ value: s.unit === 'kg' ? s.barWeightKg : s.barWeightLb, step: s.unit === 'kg' ? 2.5 : 5, attrs: `data-num="${s.unit === 'kg' ? 'barWeightKg' : 'barWeightLb'}"` })}</div>`)}
    </div></div>

    <div class="section"><div class="section-head"><h2>Appearance</h2></div><div class="card" style="padding:4px 18px">
      ${row('Theme', '', seg('theme', [['system', 'Auto'], ['light', 'Light'], ['dark', 'Dark']]))}
    </div></div>

    <div class="section"><div class="section-head"><h2>Data</h2></div><div class="card" style="padding:4px 18px">
      ${row('Import', 'Restore a backup, or bring history from Strong / Hevy / CSV', `<button class="btn btn-sm btn-primary" data-import>${I.upload} Import</button>`)}
      ${row('Export routines', 'Share or move routines as JSON', `<button class="btn btn-sm" data-export-routines>${I.download} Export</button>`)}
      ${row('Full backup', 'Everything, as JSON', `<button class="btn btn-sm" data-export-all>${I.download} Download</button>`)}
      ${row('Clear this device', state.user ? 'Signs out, keeps cloud data' : 'Deletes local routines & history', `<button class="btn btn-sm btn-danger" data-clear>${I.trash} Clear</button>`)}
    </div></div>

    <div class="section"><div class="section-head"><h2>About</h2></div><div class="card" style="padding:4px 18px">
      ${row('LiftTracker', `v${APP_VERSION} · ${installState.installed ? 'installed' : 'running in browser'}`, installState.canInstall ? `<button class="btn btn-sm btn-primary" data-install>${I.install} Install app</button>` : '')}
      ${row('Shortcuts', 'In a workout: <kbd>Enter</kbd> moves weight → reps → next set', '')}
    </div></div>
    <p class="muted" style="font-size:12px;text-align:center;margin:18px 0 6px">Weights in the cloud are stored exactly as entered, with the unit they were logged in.</p>`;
}

// Select elements don't bubble `click`; wire the rest select via delegated `change`.
document.addEventListener('change', (e) => { if (e.target.matches?.('[data-rest-sel]')) setSetting('restDefault', Number(e.target.value)); });
