// Train: routine list with start / edit / duplicate / delete / reorder, plus empty workout.
import { I } from '../icons.js';
import { esc, timeAgo, download, pickFile } from '../utils.js';
import { confirm, toast, menu } from '../ui.js';
import { state, startWorkout, deleteTemplate, restoreTemplate, duplicateTemplate, reorderTemplates, importTemplates, maximizeWorkout } from '../store.js';
import { openRoutineEditor } from '../components/routine-editor.js';
import { openImportSheet } from '../components/import.js';

export function render(root) {
  const t = state.templates;
  const next = [...t].sort((a, b) => (a.lastPerformed || 0) - (b.lastPerformed || 0))[0];
  root.innerHTML = `
    <div class="view-head">
      <h1>Train</h1>
      <div class="row"><button class="btn btn-icon" data-more aria-label="More">${I.moreH}</button><button class="btn" data-new>${I.plus} New routine</button></div>
    </div>
    ${state.active ? `<button class="card card-pad card-click" data-resume style="width:100%;text-align:left;border-color:var(--accent);display:flex;align-items:center;gap:14px;margin-bottom:14px"><div class="avatar-letter on">${I.play}</div><div style="flex:1"><b>Resume ${esc(state.active.name)}</b><div class="muted" style="font-size:12.5px">In progress · ${state.active.exercises.length} exercises</div></div>${I.chevronRight}</button>`
    : `<button class="btn btn-lg btn-block" data-empty style="margin-bottom:14px;justify-content:space-between;padding:0 18px"><span class="row">${I.zap} Start an empty workout</span>${I.chevronRight}</button>`}
    ${t.length ? `<div class="stack" data-list>${t.map((tpl, i) => card(tpl, i, tpl === next && !state.active)).join('')}</div>`
    : `<div class="empty"><div class="ico">${I.list}</div><h3>No routines</h3><p>Routines pre-fill your targets so a workout is just tapping checkmarks.</p><button class="btn btn-primary" data-new>${I.plus} Create a routine</button></div>`}`;

  root.onclick = async (e) => {
    const b = e.target.closest('button,[data-open]'); if (!b) return;
    if (b.matches('[data-new]')) return openRoutineEditor();
    if (b.matches('[data-empty]')) return startWorkout(null);
    if (b.matches('[data-resume]')) return maximizeWorkout();
    if (b.matches('[data-more]')) return menu(b, [
      { label: 'Import routines (JSON)', icon: I.upload, onClick: async () => { const txt = await pickFile(); if (!txt) return; try { const j = JSON.parse(txt); const list = Array.isArray(j) ? j : j.templates || j.routines || []; const n = importTemplates(list); toast(n ? `Imported ${n} routine${n === 1 ? '' : 's'}` : 'Nothing to import'); } catch { toast('That file isn’t valid JSON'); } } },
      { label: 'Restore backup / import history…', icon: I.history, onClick: openImportSheet },
      { label: 'Export routines (JSON)', icon: I.download, onClick: () => download(`lifttracker-routines-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify({ app: 'LiftTracker', unit: state.settings.unit, templates: state.templates }, null, 2)) },
    ]);
    const tpl = state.templates.find((x) => x.id === b.closest('[data-id]')?.dataset.id); if (!tpl) return;
    const idx = state.templates.indexOf(tpl);
    if (b.matches('[data-start]')) {
      if (state.active) { if (!await confirm({ title: 'Replace current workout?', text: 'You have a workout in progress. Starting another discards it.', confirmText: 'Replace' })) return; }
      startWorkout(tpl); return;
    }
    if (b.matches('[data-open]')) return openRoutineEditor({ template: tpl });
    if (b.matches('[data-menu]')) menu(b, [
      { label: 'Edit', icon: I.edit, onClick: () => openRoutineEditor({ template: tpl }) },
      { label: 'Duplicate', icon: I.copy, onClick: () => { duplicateTemplate(tpl.id); toast('Duplicated'); } },
      { label: 'Move up', icon: I.arrowUp, onClick: () => reorderTemplates(idx, Math.max(0, idx - 1)) },
      { label: 'Move down', icon: I.arrowDown, onClick: () => reorderTemplates(idx, Math.min(state.templates.length - 1, idx + 1)) },
      '-',
      { label: 'Delete', icon: I.trash, danger: true, onClick: async () => { if (!await confirm({ title: `Delete ${tpl.name}?`, text: 'Your workout history is kept.' })) return; const removed = deleteTemplate(tpl.id); toast('Routine deleted', { action: 'Undo', onAction: () => restoreTemplate(removed), duration: 6000 }); } },
    ]);
  };

  // Desktop drag-to-reorder (pointer-based reorder on touch is via the menu).
  let dragFrom = null;
  root.querySelectorAll('[data-id]').forEach((el) => {
    el.addEventListener('dragstart', (e) => { dragFrom = +el.dataset.i; el.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; });
    el.addEventListener('dragend', () => { el.classList.remove('dragging'); root.querySelectorAll('.drop-target').forEach((x) => x.classList.remove('drop-target')); });
    el.addEventListener('dragover', (e) => { e.preventDefault(); el.classList.add('drop-target'); });
    el.addEventListener('dragleave', () => el.classList.remove('drop-target'));
    el.addEventListener('drop', (e) => { e.preventDefault(); const to = +el.dataset.i; if (dragFrom !== null && dragFrom !== to) reorderTemplates(dragFrom, to); dragFrom = null; });
  });
}

function card(t, i, primary) {
  const names = t.exercises.map((we) => we.exercise.name);
  const sets = t.exercises.reduce((a, we) => a + we.sets.length, 0);
  return `<div class="card" data-id="${t.id}" data-i="${i}" draggable="true">
    <div class="card-pad" style="padding-bottom:12px">
      <div class="row between" style="align-items:flex-start">
        <div data-open style="flex:1;min-width:0;cursor:pointer"><h3 style="font-size:18px">${esc(t.name)}</h3><div class="meta" style="margin-top:4px"><span>${t.exercises.length} exercises</span><span>${sets} sets</span><span>${t.lastPerformed ? `last ${timeAgo(t.lastPerformed)}` : 'not done yet'}</span></div></div>
        <div class="row" style="gap:4px"><span class="drag" title="Drag to reorder">${I.grip}</span><button class="btn btn-icon btn-ghost" data-menu aria-label="Routine menu">${I.moreH}</button></div>
      </div>
      <p class="ex-line" data-open>${names.map((n) => esc(n)).join('<span class="sep">·</span>')}</p>
    </div>
    <div style="padding:0 18px 16px"><button class="btn btn-block ${primary ? 'btn-primary' : ''}" data-start>${I.play} ${primary ? 'Start routine' : 'Start'}</button></div>
  </div>`;
}
