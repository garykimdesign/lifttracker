// Active workout overlay, the minimized bar and the global rest-timer pill.
import { I } from '../icons.js';
import { esc, isNum, fmtW, fmtDuration, fmtClock, fmtVol, haptic, timeAgo } from '../utils.js';
import { openModal, confirm, toast, menu, numField, parseNum, flash, ringSvg } from '../ui.js';
import { openPicker } from '../components/picker.js';
import { openPlates } from '../components/plates.js';
import { openSummary } from '../components/summary.js';
import { openExerciseDetail } from '../components/exercise-detail.js';
import {
  state, prevPerformance, addExercisesToWorkout, removeExerciseFromWorkout, moveExercise, replaceExercise, setExerciseField,
  addSet, removeSet, updateSet, cycleSetType, addWarmups, toggleSet, updateWorkoutName, cancelWorkout, minimizeWorkout, maximizeWorkout,
  finishWorkout, startRest, adjustRest, stopRest, restRemaining, findExerciseByName,
} from '../store.js';

const KIND = { weight: 'heaviest', e1rm: 'est. 1RM', volume: 'set volume' };
const TYPE_LABEL = { W: 'Warm-up', D: 'Drop set', F: 'To failure' };
let timerInt = null;
let wakeLock = null;
let audioCtx = null;

// ---------- Workout sheet ----------
export function renderWorkout(root) {
  const a = state.active;
  clearInterval(timerInt);
  if (!a || state.minimized) { root.innerHTML = ''; releaseWake(); return; }
  const unit = a.unit || state.settings.unit;
  const done = a.exercises.reduce((n, we) => n + we.sets.filter((s) => s.completed).length, 0);
  const total = a.exercises.reduce((n, we) => n + we.sets.length, 0);
  const vol = a.exercises.reduce((n, we) => n + we.sets.filter((s) => s.completed && s.type !== 'W' && isNum(s.weight) && isNum(s.reps)).reduce((m, s) => m + s.weight * s.reps, 0), 0);

  // Preserve scroll + focus across structural re-renders.
  const prevBody = root.querySelector('.wk-body');
  const scrollY = prevBody?.scrollTop || 0;
  const focused = document.activeElement?.closest?.('.workout-sheet') ? { set: document.activeElement.closest('[data-set]')?.dataset.set, f: document.activeElement.dataset.f } : null;

  root.innerHTML = `<div class="workout-sheet" role="dialog" aria-label="Active workout">
    <div class="wk-head"><div class="wk-head-inner">
      <div><button class="btn btn-icon btn-ghost" data-min aria-label="Minimize">${I.chevronDown}</button></div>
      <div class="wk-timer">${I.timer}<span data-timer>${fmtDuration(Date.now() - a.startTime)}</span></div>
      <div class="r"><button class="btn btn-primary btn-sm" data-finish>Finish</button></div>
    </div></div>
    <div class="wk-body">
      <div style="padding:6px 2px 14px">
        <input class="title-input" data-name value="${esc(a.name)}" placeholder="Workout name" maxlength="80">
        <div class="meta" style="margin-top:6px"><span data-prog>${done}/${total} sets</span><span data-vol>${fmtVol(vol)} ${unit}</span><span>${a.exercises.length} exercise${a.exercises.length === 1 ? '' : 's'}</span></div>
      </div>
      ${a.exercises.length ? a.exercises.map((we, i) => exCard(we, i, a, unit)).join('') : `<div class="empty"><div class="ico">${I.dumbbell}</div><h3>Empty workout</h3><p>Add your first exercise to start logging sets.</p></div>`}
      <div class="wk-actions">
        <button class="btn btn-lg btn-block ${a.exercises.length ? '' : 'btn-primary'}" data-add>${I.plus} Add exercise</button>
        <button class="btn btn-lg btn-block btn-ghost" data-cancel style="color:var(--danger)">Discard workout</button>
      </div>
    </div>
  </div>`;

  const body = root.querySelector('.wk-body');
  body.scrollTop = scrollY;
  if (focused?.set) { const el = body.querySelector(`[data-set="${focused.set}"] [data-f="${focused.f}"]`); el?.focus({ preventScroll: true }); }
  timerInt = setInterval(() => { const t = root.querySelector('[data-timer]'); if (t && state.active) t.textContent = fmtDuration(Date.now() - state.active.startTime); }, 1000);
  requestWake();

  const findCtx = (el) => { const weId = el.closest('[data-we]')?.dataset.we; const setId = el.closest('[data-set]')?.dataset.set; return { weId, setId, we: a.exercises.find((x) => x.id === weId) }; };

  // --- Input edits (silent: no re-render) ---
  root.addEventListener('input', (e) => {
    const t = e.target;
    if (t.matches('[data-name]')) return updateWorkoutName(t.value);
    if (t.matches('[data-notes]')) { const { weId } = findCtx(t); return setExerciseField(weId, { notes: t.value || undefined }); }
    if (t.dataset.f) {
      const { weId, setId } = findCtx(t);
      updateSet(weId, setId, { [t.dataset.f]: parseNum(t.value) });
      const row = t.closest('.set-row'); row.classList.remove('done', 'pr'); row.querySelector('.set-check')?.classList.remove('on');
      refreshStats(root);
    }
  });
  root.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const t = e.target; if (!t.dataset?.f) return;
    e.preventDefault();
    const row = t.closest('.set-row');
    if (t.dataset.f === 'weight') { row.querySelector('[data-f="reps"]')?.focus(); return; }
    // reps → complete set and jump to the next row's weight
    const { weId, setId } = findCtx(t);
    if (!row.classList.contains('done')) completeSet(root, weId, setId, row);
    const next = row.nextElementSibling?.matches('.set-row') ? row.nextElementSibling : null;
    (next?.querySelector('[data-f="weight"]') || t).focus();
    if (!next) t.blur();
  });
  root.addEventListener('focusin', (e) => { if (e.target.dataset?.f) e.target.select?.(); });

  // --- Clicks ---
  root.addEventListener('click', async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.matches('[data-min]')) return minimizeWorkout();
    if (b.matches('[data-finish]')) return finish();
    if (b.matches('[data-cancel]')) { if (await confirm({ title: 'Discard this workout?', text: 'Completed sets will not be saved.', confirmText: 'Discard' })) { cancelWorkout(); stopRest(); } return; }
    if (b.matches('[data-add]')) return openPicker({ title: 'Add exercises', onPick: (list) => { addExercisesToWorkout(list); haptic(); } });
    const { weId, setId, we } = findCtx(b);
    if (!we) return;
    if (b.matches('[data-check]')) { const row = b.closest('.set-row'); if (row.classList.contains('done')) { toggleSet(weId, setId); row.classList.remove('done', 'pr'); b.classList.remove('on'); refreshStats(root); } else completeSet(root, weId, setId, row); return; }
    if (b.matches('[data-type]')) { cycleSetType(weId, setId); return; }
    if (b.matches('[data-del]')) { if (we.sets.length <= 1) { toast('Remove the exercise instead'); return; } removeSet(weId, setId); return; }
    if (b.matches('[data-addset]')) { addSet(weId); setTimeout(() => { const rows = root.querySelectorAll(`[data-we="${weId}"] .set-row`); rows[rows.length - 1]?.querySelector('[data-f="weight"]')?.focus(); }, 30); return; }
    if (b.matches('[data-warm]')) { if (!addWarmups(weId)) toast('Enter a working weight first'); return; }
    if (b.matches('[data-plates]')) { const w = we.sets.find((s) => !s.completed && isNum(s.weight))?.weight ?? we.sets.find((s) => isNum(s.weight))?.weight; return openPlates(w); }
    if (b.matches('[data-notes-btn]')) { setExerciseField(weId, { notes: we.notes || '' }); setTimeout(() => root.querySelector(`[data-we="${weId}"] [data-notes]`)?.focus(), 30); return; }
    if (b.matches('[data-info]')) { const ex = findExerciseByName(we.exercise.name) || we.exercise; return openExerciseDetail(ex); }
    if (b.matches('[data-exmenu]')) menu(b, [
      { label: 'Exercise details', icon: I.trending, onClick: () => openExerciseDetail(findExerciseByName(we.exercise.name) || we.exercise) },
      { label: 'Replace exercise', icon: I.swap, onClick: () => openPicker({ title: 'Replace with', multi: false, onPick: ([ex]) => replaceExercise(weId, ex) }) },
      { label: 'Rest timer for this exercise', icon: I.timer, onClick: () => pickRest(we) },
      { label: we.notes !== undefined ? 'Remove notes' : 'Add notes', icon: I.note, onClick: () => setExerciseField(weId, { notes: we.notes !== undefined ? undefined : '' }) },
      { label: 'Move up', icon: I.arrowUp, onClick: () => moveExercise(weId, -1) },
      { label: 'Move down', icon: I.arrowDown, onClick: () => moveExercise(weId, 1) },
      '-',
      { label: 'Remove exercise', icon: I.trash, danger: true, onClick: () => removeExerciseFromWorkout(weId) },
    ]);
  });
}

function exCard(we, i, a, unit) {
  const prev = prevPerformance(we.exercise.name);
  const prevWorking = prev ? prev.sets.filter((s) => s.type !== 'W') : [];
  const rest = isNum(we.restTime) ? we.restTime : state.settings.restDefault;
  return `<div class="ex-card" data-we="${we.id}">
    <div class="ex-head">
      <div style="flex:1;min-width:0">
        <h3><button data-info style="text-align:left;font:inherit;letter-spacing:inherit">${esc(we.exercise.name)}</button></h3>
        <div class="sub"><span>${esc(we.exercise.muscleGroup)}</span><span>· ${I.timer} ${fmtClock(rest)}</span>${prev ? `<span>· last ${timeAgo(prev.date)}: ${prevWorking.slice(0, 3).map((s) => `${fmtW(s.weight, unit)}×${s.reps}`).join(', ')}${prevWorking.length > 3 ? '…' : ''}</span>` : '<span>· first time</span>'}</div>
      </div>
      <div class="ex-menu"><button class="btn btn-icon btn-ghost btn-sm" data-exmenu aria-label="Exercise menu">${I.moreH}</button></div>
    </div>
    <div class="set-grid header"><span>Set</span><span>${unit}</span><span>Reps</span><span>${I.check}</span><span></span></div>
    ${we.sets.map((s, j) => setRow(s, j, prev, unit)).join('')}
    <div class="ex-foot">
      <button class="btn btn-sm" data-addset>${I.plus} Set</button>
      <button class="btn btn-sm" data-warm title="Generate warm-up ramp">${I.flame} Warm-up</button>
      <button class="btn btn-sm" data-plates title="Plate calculator">${I.plates} Plates</button>
      ${we.notes === undefined ? `<button class="btn btn-sm btn-icon" data-notes-btn aria-label="Add notes">${I.note}</button>` : ''}
    </div>
    ${we.notes !== undefined ? `<div class="ex-notes"><textarea class="textarea" data-notes placeholder="Notes for this exercise…">${esc(we.notes)}</textarea></div>` : ''}
  </div>`;
}

function setRow(s, j, prev, unit) {
  // Number only working sets; warm-ups show "W".
  const p = prev?.sets?.[j];
  const prevTxt = p && isNum(p.weight) && isNum(p.reps) ? `${fmtW(p.weight, unit)}×${p.reps}` : '';
  return `<div class="set-row ${s.completed ? 'done' : ''} ${s.pr?.length ? 'pr' : ''}" data-set="${s.id}">
    <div class="set-grid">
      <div class="set-no ${(s.type || '').toLowerCase()}"><button data-type title="${TYPE_LABEL[s.type] || 'Tap to mark warm-up / drop / failure'}">${s.type || j + 1}${prevTxt ? `<span class="prev">${prevTxt}</span>` : ''}</button></div>
      ${numField({ value: s.weight, compact: true, placeholder: p && isNum(p.weight) ? fmtW(p.weight, unit) : '—', attrs: 'data-f="weight"' })}
      ${numField({ value: s.reps, compact: true, inputmode: 'numeric', placeholder: p && isNum(p.reps) ? String(p.reps) : '—', attrs: 'data-f="reps"' })}
      <button class="set-check ${s.completed ? 'on' : ''}" data-check aria-label="${s.completed ? 'Mark incomplete' : 'Complete set'}">${I.check}</button>
      <button class="set-del" data-del aria-label="Remove set">${I.x}</button>
    </div>
  </div>`;
}

function completeSet(root, weId, setId, row) {
  // Adopt placeholders (previous performance) when fields are left blank.
  for (const f of ['weight', 'reps']) {
    const inp = row.querySelector(`[data-f="${f}"]`);
    if (inp.value.trim() === '' && inp.placeholder && inp.placeholder !== '—') { inp.value = inp.placeholder; updateSet(weId, setId, { [f]: parseNum(inp.value) }); }
  }
  const r = toggleSet(weId, setId);
  if (!r || r.error) { for (const f of ['weight', 'reps']) { const inp = row.querySelector(`[data-f="${f}"]`); if (inp.value.trim() === '') flash(inp.closest('.numfield')); } haptic([10, 30, 10]); return; }
  row.classList.add('done'); row.querySelector('.set-check').classList.add('on');
  haptic(14); unlockAudio();
  if (r.pr) { row.classList.add('pr'); const we = state.active.exercises.find((x) => x.id === weId); toast(`${I.trophy} <b>PR!</b> ${esc(we.exercise.name)} — ${r.pr.map((k) => KIND[k]).join(', ')}`, { kind: 'pr', duration: 4200 }); }
  if (r.rest) { const we = state.active.exercises.find((x) => x.id === weId); startRest(r.rest, we.exercise.name); ensureNotifyPermission(); }
  refreshStats(root);
  document.activeElement?.blur?.();
}

function refreshStats(root) {
  const a = state.active; if (!a) return;
  const done = a.exercises.reduce((n, we) => n + we.sets.filter((s) => s.completed).length, 0);
  const total = a.exercises.reduce((n, we) => n + we.sets.length, 0);
  const vol = a.exercises.reduce((n, we) => n + we.sets.filter((s) => s.completed && s.type !== 'W' && isNum(s.weight) && isNum(s.reps)).reduce((m, s) => m + s.weight * s.reps, 0), 0);
  const p = root.querySelector('[data-prog]'), v = root.querySelector('[data-vol]');
  if (p) p.textContent = `${done}/${total} sets`;
  if (v) v.textContent = `${fmtVol(vol)} ${a.unit || state.settings.unit}`;
}

function pickRest(we) {
  const opts = [0, 30, 45, 60, 90, 120, 150, 180, 240, 300];
  openModal({
    title: `Rest after ${we.exercise.name}`,
    html: `<div class="chips wrap" style="flex-wrap:wrap">${opts.map((v) => `<button class="chip ${(isNum(we.restTime) ? we.restTime : -1) === v ? 'on' : ''}" data-v="${v}">${v === 0 ? 'Off' : fmtClock(v)}</button>`).join('')}<button class="chip ${!isNum(we.restTime) ? 'on' : ''}" data-v="">Default (${fmtClock(state.settings.restDefault)})</button></div>`,
    onMount(h) { h.body.addEventListener('click', (e) => { const c = e.target.closest('[data-v]'); if (!c) return; setExerciseField(we.id, { restTime: c.dataset.v === '' ? undefined : Number(c.dataset.v) }); h.close(); }); },
  });
}

async function finish() {
  const a = state.active; if (!a) return;
  const completed = a.exercises.reduce((n, we) => n + we.sets.filter((s) => s.completed).length, 0);
  const pending = a.exercises.reduce((n, we) => n + we.sets.filter((s) => !s.completed).length, 0);
  if (!completed) { if (await confirm({ title: 'No sets completed', text: 'Finish anyway to discard this workout, or go back and log a set.', confirmText: 'Discard' })) { cancelWorkout(); stopRest(); } return; }
  if (pending && !await confirm({ title: `Finish with ${pending} set${pending > 1 ? 's' : ''} left?`, text: 'Unchecked sets are dropped from the log.', confirmText: 'Finish', danger: false, icon: I.check })) return;
  const r = finishWorkout();
  stopRest(); releaseWake();
  if (r) { haptic([12, 40, 12]); openSummary(r); }
}

// ---------- Minimized bar ----------
export function renderMiniBar(root) {
  const a = state.active;
  if (!a || !state.minimized) { root.innerHTML = ''; return; }
  const done = a.exercises.reduce((n, we) => n + we.sets.filter((s) => s.completed).length, 0);
  const total = a.exercises.reduce((n, we) => n + we.sets.length, 0);
  root.innerHTML = `<button class="mini-bar" data-max aria-label="Return to workout"><div class="ico">${I.dumbbell}</div><div style="min-width:0;text-align:left"><div class="k">In progress</div><div class="n">${esc(a.name)}</div></div><span class="num" data-mini-timer>${fmtDuration(Date.now() - a.startTime)}</span><span class="rest">${done}/${total}</span></button>`;
  root.querySelector('[data-max]').onclick = () => maximizeWorkout();
  clearInterval(renderMiniBar.int);
  renderMiniBar.int = setInterval(() => { const t = root.querySelector('[data-mini-timer]'); if (!t || !state.active) return clearInterval(renderMiniBar.int); t.textContent = fmtDuration(Date.now() - state.active.startTime); }, 1000);
}

// ---------- Rest pill ----------
export function renderRest(root, detail) {
  const r = state.rest;
  if (!r) { root.innerHTML = ''; return; }
  const left = restRemaining();
  const existing = root.querySelector('.rest-bar');
  if (existing && !detail?.finished && existing.dataset.total === String(r.total)) {
    // Fast path: tick only.
    existing.querySelector('[data-left]').textContent = fmtClock(left);
    const c = existing.querySelector('circle.fg'); const circ = parseFloat(c.getAttribute('stroke-dasharray')); c.setAttribute('stroke-dashoffset', String(circ * (1 - left / r.total)));
    existing.classList.toggle('done', r.done);
    return;
  }
  root.innerHTML = `<div class="rest-bar ${r.done ? 'done' : ''}" data-total="${r.total}" role="timer">
    <div class="ring">${ringSvg(left / r.total, 46, 4)}<div class="t">${I.timer}</div></div>
    <div class="lbl"><div class="k">${r.done ? 'Rest over' : 'Rest'}${r.label ? ` · ${esc(r.label)}` : ''}</div><div class="v" data-left>${fmtClock(left)}</div></div>
    <button class="btn" data-adj="-15">−15</button><button class="btn" data-adj="15">+15</button><button class="btn" data-skip>${r.done ? 'Done' : 'Skip'}</button>
  </div>`;
  root.querySelector('.rest-bar').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; if (b.dataset.adj) adjustRest(+b.dataset.adj); else stopRest(); };
  if (detail?.finished) notifyRestDone(r);
}

function notifyRestDone(r) {
  if (state.settings.restVibrate) haptic([80, 60, 80, 60, 160]);
  if (state.settings.restSound) beep();
  if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
    try { navigator.serviceWorker?.ready.then((reg) => reg.showNotification('Rest over', { body: r.label ? `Next set: ${r.label}` : 'Time for your next set', icon: 'icons/icon-192.png', tag: 'rest', vibrate: [80, 60, 80] })).catch(() => new Notification('Rest over', { body: 'Time for your next set' })); } catch {}
  }
}
function ensureNotifyPermission() { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().catch(() => {}); }
function unlockAudio() { try { if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)(); if (audioCtx.state === 'suspended') audioCtx.resume(); } catch {} }
function beep() {
  try {
    unlockAudio(); if (!audioCtx) return;
    const t0 = audioCtx.currentTime;
    [0, 0.18, 0.36].forEach((dt, i) => { const o = audioCtx.createOscillator(), g = audioCtx.createGain(); o.type = 'sine'; o.frequency.value = i === 2 ? 1046 : 784; g.gain.setValueAtTime(0.0001, t0 + dt); g.gain.exponentialRampToValueAtTime(0.25, t0 + dt + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dt + 0.16); o.connect(g).connect(audioCtx.destination); o.start(t0 + dt); o.stop(t0 + dt + 0.18); });
  } catch {}
}
async function requestWake() { try { if ('wakeLock' in navigator && !wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); } } catch {} }
function releaseWake() { try { wakeLock?.release(); } catch {} wakeLock = null; }
document.addEventListener('visibilitychange', () => { if (!document.hidden && state.active && !state.minimized) requestWake(); });
